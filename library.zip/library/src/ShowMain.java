//ShowMain.java
import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
import javax.swing.ImageIcon;
import javax.swing.JLabel;
import javax.swing.JMenu;
import javax.swing.JMenuBar;
import javax.swing.JMenuItem;
import javax.swing.JPanel;
import javax.swing.SwingConstants;
import javax.swing.event.MenuEvent;
import javax.swing.event.MenuListener;
public class ShowMain extends JFrame{
	JMenuBar menubar1;
	JMenu menu1,menu2,menu3,menu4,menu5,menu6,menu7,menu8;
	JMenu menu9;
	JMenuItem mi_book_add,mi_book_update,mi_book_delete,mi_reader_add,mi_reader_update,mi_reader_delete;
	JMenuItem mi_borrow,mi_back,mi_query_book,mi_query_reader,mi_update_pass,mi_exit;
	private ImageIcon main_icon;
	private JLabel backimg;
	private JLabel team;
	//Ȩ������
	public void setRights(String right){
		if(right.equals("��")){
			menu1.setEnabled(false);
			menu5.setEnabled(false);
		}
	}
	public ShowMain(){
		setTitle("ͼ�����ϵͳ");	
		setLayout(new BorderLayout());
		setSize(800,600);
		setResizable(false);
		main_icon=new ImageIcon("src/img/mainbk.jpg");
		backimg=new JLabel();
		backimg.setIcon(main_icon);
		backimg.setBounds(0, 0, 800, 600);
		
		
		menubar1=new JMenuBar();
		menu5=new JMenu("����ά��");
		menu6=new JMenu("ͼ��ά��");
		mi_book_add=new JMenuItem("����");
		mi_book_update=new JMenuItem("�޸�");
		mi_book_delete=new JMenuItem("ɾ��");
		menu7=new JMenu("����ά��");
		mi_reader_add=new JMenuItem("���Ӷ���");
		mi_reader_update=new JMenuItem("�޸Ķ���");
		mi_reader_delete=new JMenuItem("ɾ������");
		menu1=new JMenu("���Ĺ���");
		mi_borrow=new JMenuItem("�������");
		mi_back=new JMenuItem("�������");
		menu2=new JMenu("��ѯ����");
		mi_query_book=new JMenuItem("ͼ���ѯ");
		mi_query_reader=new JMenuItem("���߲�ѯ");
		menu3=new JMenu("ϵͳ����");
		mi_update_pass=new JMenuItem("�޸�����");
		mi_exit=new JMenuItem("�˳�ϵͳ");
		menu9=new JMenu("�����Ŷ�");
	
		menu5.setFont(new Font("����",Font.BOLD,20));
		menu1.setFont(new Font("����",Font.BOLD,20));
		menu2.setFont(new Font("����",Font.BOLD,20));
		menu3.setFont(new Font("����",Font.BOLD,20));
		menu9.setFont(new Font("����",Font.BOLD,20));
		
		menu6.setFont(new Font("����",Font.BOLD,17));
		menu7.setFont(new Font("����",Font.BOLD,17));
		mi_borrow.setFont(new Font("����",Font.BOLD,17));
		mi_back.setFont(new Font("����",Font.BOLD,17));
		mi_query_book.setFont(new Font("����",Font.BOLD,17));
		mi_query_reader.setFont(new Font("����",Font.BOLD,17));
		mi_update_pass.setFont(new Font("����",Font.BOLD,17));
		mi_exit.setFont(new Font("����",Font.BOLD,17));
		mi_book_add.setFont(new Font("����",Font.BOLD,17));
		mi_book_update.setFont(new Font("����",Font.BOLD,17));
		mi_book_delete.setFont(new Font("����",Font.BOLD,17));
		mi_reader_add.setFont(new Font("����",Font.BOLD,17));
		mi_reader_update.setFont(new Font("����",Font.BOLD,17));
		mi_reader_delete.setFont(new Font("����",Font.BOLD,17));
	
		team=new JLabel();
		team.setAlignmentX(CENTER_ALIGNMENT);
		team.setHorizontalAlignment(SwingConstants.CENTER);
		team.setBounds(20,10,600,400);
		team.setFont(new Font("����",Font.BOLD,36));
		team.setText("<html>ͼ�����ϵͳ�����Ŷӽ��� <br>֣�� <br> Ԭ�� <br> ������ <br> ���Կ� <br> ��� <br><html>");
		team.setVisible(false);
		add(team);
		menu5.add(menu6);                
		menu6.add(mi_book_add);
		menu6.add(mi_book_update);     
		menu6.add(mi_book_delete);
		menu5.add(menu7);	     
		menu7.add(mi_reader_add);
		menu7.add(mi_reader_update);   
		menu7.add(mi_reader_delete);
		menu5.add(menu1);	      
		menu1.add(mi_borrow);
		menu1.add(mi_back);	       
		menu5.add(menu2);
		menu2.add(mi_query_book);       
		menu2.add(mi_query_reader);
		menu5.add(menu3);	       
		menu3.add(mi_update_pass);
		menu3.add(mi_exit);	     
		menubar1.add(menu5);
		menubar1.add(menu1);	
		menubar1.add(menu2);
		menubar1.add(menu3);
		menubar1.add(menu9); 
		setJMenuBar(menubar1);
		add(backimg);
		mi_book_add.addActionListener(new ActionListener(){
			public void actionPerformed(ActionEvent e){
				dispose();
				new BookAdd();
			}
		});
		mi_book_update.addActionListener(new ActionListener(){
			public void actionPerformed(ActionEvent e){
				dispose();
				new BookUpdate();
			}
		});
		mi_book_delete.addActionListener(new ActionListener(){
			public void actionPerformed(ActionEvent e){
				dispose();
				new BookDelete();
			}
		});
		mi_reader_add.addActionListener(new ActionListener(){
			public void actionPerformed(ActionEvent e){
				dispose();
				new ReaderAdd();
			}
		});
		mi_reader_update.addActionListener(new ActionListener(){
			public void actionPerformed(ActionEvent e){
				dispose();new ReaderUpdate();
			}
		});
		mi_reader_delete.addActionListener(new ActionListener(){
			public void actionPerformed(ActionEvent e){
				dispose();new ReaderDelete();
			}
		});
		
		mi_borrow.addActionListener(new ActionListener(){
			public void actionPerformed(ActionEvent e){
				dispose();new Borrow();
			}
		});
		
		mi_back.addActionListener(new ActionListener(){
			public void actionPerformed(ActionEvent e){
				dispose();new Back();
			}
		});
		mi_query_book.addActionListener(new ActionListener(){
			public void actionPerformed(ActionEvent e){
				dispose();new BookQuery();
			}
		});
		mi_query_reader.addActionListener(new ActionListener(){
			public void actionPerformed(ActionEvent e){
				dispose();new ReaderQuery();
			}
		});
		mi_update_pass.addActionListener(new ActionListener(){
			public void actionPerformed(ActionEvent e){
				dispose();new ChangePassWord();
			}
		});
		
		mi_exit.addActionListener(new ActionListener(){
			public void actionPerformed(ActionEvent e){
				dispose();DbOp.close();
				System.exit(0);
			}
		});
		menu9.addMenuListener(new MenuListener() {
			
			@Override
			public void menuSelected(MenuEvent e) {
				// TODO �Զ����ɵķ������
				team.setVisible(true);
			}
			
			@Override
			public void menuDeselected(MenuEvent e) {
				// TODO �Զ����ɵķ������
				team.setVisible(false);
			}
			
			@Override
			public void menuCanceled(MenuEvent e) {
				// TODO �Զ����ɵķ������
				
			}
		});
		
		addWindowListener(new WindowAdapter(){
			public void windowClosing(WindowEvent e){
				DbOp.close();
				System.exit(0);
			}
		});
		
		setLocationRelativeTo(null);
		setVisible(true);
	}
	public static void main(String[] args){
		new ShowMain();
	}
}