//Login.java
//import PublicModule.DbOp;
import java.awt.*;
import javax.swing.*;
import java.awt.event.*;
import java.sql.*;

public class Login extends Frame{
	Toolkit tool= getToolkit();
	String url="src/img/login.png";
	Image img=tool.getImage(url);
	private JProgressBar progressBar;
	private TextField text_user;
	private TextField text_pass;
	private JLabel title;
	private JLabel userlb;
	private JLabel passlb;
	private JLabel register;
	
	

	public void paint(Graphics g){
		g.drawImage(img,0,0,this);
		super.paint(g);
	}
	public Login(){
		this.setTitle("Login");
		this.setLayout(null);
		this.setSize(1129,542);
		setResizable(false);
		
	    //标签设置
		userlb=new JLabel("UserName:");
		passlb=new JLabel("PassWord:");
		title=new JLabel("武汉理工大学图书管理系统");
		JButton sure=new JButton("Login");
		sure.setFocusPainted(false);
		JButton cancel=new JButton("Cancel");
		cancel.setFocusPainted(false);
		//设置透明度
		sure.setContentAreaFilled(false);
		cancel.setContentAreaFilled(false);
		//设置边框
		sure.setBorder(BorderFactory.createLineBorder(Color.black));
		cancel.setBorder(BorderFactory.createLineBorder(Color.black));
		register=new JLabel("还没有账号？点击注册新用户");
		text_user=new TextField();
		text_pass=new TextField();
	
		
		
		title.setFont(new Font("楷体",Font.BOLD,30));
		userlb.setFont(new Font("微软雅黑",Font.PLAIN,20));
		passlb.setFont(new Font("微软雅黑",Font.PLAIN,20));
		
		
		title.setBounds(700,140,400,50);
		userlb.setBounds(650,200,110,35);
		passlb.setBounds(650,250,100,35);
		text_user.setBounds(770,200,200,35);
		text_pass.setBounds(770,250,200,35);
		sure.setBounds(770,300,100,35);
		cancel.setBounds(890,300,100,35);
		register.setBounds(770,370,200,20);
		text_user.setFont(new Font("楷体",Font.BOLD,20));
		text_pass.setFont(new Font("楷体",Font.BOLD,20));
		text_pass.setEchoChar('*');
		sure.setFont(new Font("楷体",Font.PLAIN,20));
		cancel.setFont(new Font("楷体",Font.PLAIN,20));
		register.setFont(new Font("楷体",Font.PLAIN,15));
		
		//进度条设置
		progressBar=new JProgressBar(0,100);
        progressBar.setStringPainted(true);
        progressBar.setMaximum(100);
        progressBar.setMinimum(0);
        progressBar.setBounds(680,400,400,30);
        progressBar.setForeground(Color.gray);
        progressBar.setVisible(false);
        
		this.add(title);
		this.add(register);
		this.add(text_user);
		this.add(text_pass);
		this.add(userlb);
		this.add(passlb);
		this.add(sure);
		this.add(cancel);
		this.add(progressBar);
		register.addMouseListener(new MouseListener() {
			@Override
			public void mouseEntered(MouseEvent e) {
				// TODO 自动生成的方法存根
				register.setText("<html><u>还没有账号？点击注册新用户</u><html>");
				register.setForeground(Color.blue);
				
			}
			
			@Override
			public void mouseClicked(MouseEvent e) {
				dispose();
				new register();
			}

			@Override
			public void mouseExited(MouseEvent e) {
				// TODO 自动生成的方法存根
				register.setText("还没有账号？点击注册新用户");
				register.setForeground(Color.black);
			}

			@Override
			public void mousePressed(MouseEvent e) {
				// TODO 自动生成的方法存根
				
			}

			@Override
			public void mouseReleased(MouseEvent e) {
				// TODO 自动生成的方法存根
				
			}
		});
		sure.addActionListener(new ActionListener(){
			public void actionPerformed(ActionEvent e){
				sureActionListener(e);
				
			}
		});
		cancel.addActionListener(new ActionListener(){
			public void actionPerformed(ActionEvent e){
				DbOp.close();
				dispose();

			}
		});
		
		this.addWindowListener(new WindowAdapter(){
			public void windowClosing(WindowEvent e){
				DbOp.close();
				dispose();
			}
		});
		this.setLocationRelativeTo(null);
		this.setVisible(true);
	}
	//确定事件
	public void sureActionListener(ActionEvent le){
		
		String user=text_user.getText();
		String pass=text_pass.getText();
		String is_admin="";
		if(user.equals("")||pass.equals("")){
			JOptionPane.showMessageDialog(null,"密码不能为空，请输入密码");
			return;
		}
		try{
			String sql="select * from user where username="+"'"+user+"'"+"and password="+"'"+pass+"'";
			ResultSet rs=DbOp.executeQuery(sql);
				if(rs.next())
				{
					progressBar.setVisible(true);
					register.setVisible(false);
					is_admin=rs.getString("is_admin");
					//设置全局变量
					GlobalVar.login_user=user;	
					GlobalVar.manage=is_admin;
					new Thread()
					{
						public void run()
						{
							int i=0;
							for(i=0;i<101;i++)
							{
								try {
									
									sleep(70);
								} catch (InterruptedException e) {
									JOptionPane.showMessageDialog(null, e.getMessage());
								}
								if(i<=20)progressBar.setForeground(Color.green);		
								else if(i>20&&i<=40)progressBar.setForeground(Color.orange);
								else if(i>40&&i<60)progressBar.setForeground(Color.pink);
								else if(i>60&&i<80)progressBar.setForeground(new Color(154,223,237));
								else if(i>=80)progressBar.setForeground(new Color(237,33,111));
								
								progressBar.setString("数据库加载中 "+i+"%");
								progressBar.setValue(i);
							}
							if(i==101)
							{
								progressBar.setForeground(Color.red);
								progressBar.setString("数据库加载完成");
								try {
									sleep(1000);
								} catch (InterruptedException e) {
									JOptionPane.showMessageDialog(null,e.getMessage());
								}
								dispose();
								ShowMain show=new ShowMain();
								show.setRights(GlobalVar.manage);
								
							}
						}
					}.start();
					System.out.println("Successed");
				}
				
				else{
					JOptionPane.showMessageDialog(null,"Wrong that is UserNmae or Password ");
					return;
				}
			
		}catch(SQLException e){
			JOptionPane.showMessageDialog(null,"the wrong from information");
		}
	}
	
	//进度条函数


	
	
	public static void main(String[] args){
		
		//设置适应window10风格
		try {
			UIManager.setLookAndFeel(UIManager.getSystemLookAndFeelClassName());
		}catch (ClassNotFoundException | InstantiationException | IllegalAccessException 
				|UnsupportedLookAndFeelException e) {
			JOptionPane.showMessageDialog(null, e.getMessage());
		}
		try {
			new Login();
		} catch (Exception e) {
			JOptionPane.showMessageDialog(null, e.getMessage());
		}
	}
}