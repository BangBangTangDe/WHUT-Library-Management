//GlobalVar.java
public class GlobalVar{
	public static String login_user;
	public static String manage;
} 