/**
* @author xiaobao
* @version ����ʱ�䣺2019��12��20�� ����3:37:28
* @ClassName ������
* @Description ������
*/
package test;
import libraryManage.*;
import static org.junit.Assert.*;

import org.junit.Before;
import org.junit.Test;

/**
 * @author 12852
 *
 */
public class IfBorrowBackTest {

	static IfBorrowBack test;
	/**
	 * @throws java.lang.Exception
	 */
	@Before
	public void setUp() throws Exception {
	}
	

	@Test
	public void test() {
		assertFalse(test.findBook("A00001", "1"));
		assertTrue(test.findBook("A00002", "2"));
	}

}
