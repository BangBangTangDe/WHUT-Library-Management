/**
* @author xiaobao
* @version ����ʱ�䣺2019��12��20�� ����3:58:12
* @ClassName ������
* @Description ������
*/
package test;

import static org.junit.Assert.*;
import java.sql.*;
import java.util.Date;
import java.util.*;
import java.text.*;
import org.junit.Before;
import org.junit.Test;
import libraryManage.*;
import java.util.*;

/**
 * @author 12852
 *
 */
public class BorrowTest {

	 Borrow test;
	/**
	 * @throws java.lang.Exception
	 */
	@Before
	public void setUp() throws Exception {
		test=new Borrow();
		test.bookidtxt.setText("A00003");
		test.readeridtxt.setText("7");
	}


	@Test
	public void testGetImposeRestrictionsOnDays_num() {
		System.out.println(test.getImposeRestrictionsOnDays_num("7"));
		assertTrue(test.getImposeRestrictionsOnDays_num("7").equals("20"));
	}

	
	@SuppressWarnings("unlikely-arg-type")
	@Test
	public void testGetBorrowDate() {
		assertTrue(test.getBorrowDate("A00003", "7").toString().equals("Sat Nov 30 00:00:00 CST 2019"));
	}

	@Test
	public void testIfLeapYear() {
		assertEquals(true,test.IfLeapYear(2000) );
	}


	@Test
	public void testGetReaderBorrowDays() {
		Date begin=new Date();
		Date end=new Date();
		SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
		try {
			begin = sdf.parse("2019-11-30");
			end=sdf.parse("2019-12-20");
		} catch (ParseException e) {
			// TODO �Զ����ɵ� catch ��
			e.printStackTrace();
		}
		assertTrue(test.getReaderBorrowDays(begin,end).equals("20"));
	}

	@Test
	public void testGetReaderBorrowBookCounts() {
		assertTrue(test.getReaderBorrowBookCounts("7").equals("1") );
		
	}

	/**
	 * {@link libraryManage.Borrow#getInsertOrderedList()} �Ĳ��Է�����
	 */
	@Test
	public void testGetInsertOrderedList() {
		System.out.println(test.getInsertOrderedList());
		assertTrue(test.getInsertOrderedList().equals("3"));
	}

}
