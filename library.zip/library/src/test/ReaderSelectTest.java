/**
* @author xiaobao
* @version ����ʱ�䣺2019��12��20�� ����3:13:43
* @ClassName ������
* @Description ������
*/
package test;

import static org.junit.Assert.*;

import org.junit.Before;
import org.junit.Test;

import libraryManage.*;
/**
 * @author 12852
 *
 */
public class ReaderSelectTest {
	static ReaderSelect test;
	/**
	 * @throws java.lang.Exception
	 */
	@Before
	public void setUp() throws Exception {
	}

	/**
	 * {@link libraryManage.ReaderSelect#SelectReaderByID(java.lang.String)} �Ĳ��Է�����
	 */
	@Test
	public void testSelectReaderByID() {
		Reader rs=new Reader();
		rs.setId("9");
		rs.setReadername("����");
		rs.setReadertype("��ʦ");
		rs.setReaderSex("��");
		rs.setMax_num(5);
		rs.setDays_num(90);
		//assertFalse(rs.equals(test.SelectReaderByID("9"))==true);
		assertEquals(rs.getId(), test.SelectReaderByID("9").getId());
		assertEquals(rs.getReadername(), test.SelectReaderByID("9").getReadername());
		assertEquals(rs.getReaderSex(), test.SelectReaderByID("9").getReaderSex());
		assertEquals(rs.getReadertype(), test.SelectReaderByID("9").getReadertype());
		assertEquals(rs.getReadertype(), test.SelectReaderByID("9").getReadertype());
		assertEquals(rs.getDays_num(), test.SelectReaderByID("9").getDays_num());
		assertEquals(rs.getMax_num(), test.SelectReaderByID("9").getMax_num());
		
	}

}
