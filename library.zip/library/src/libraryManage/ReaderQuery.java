package libraryManage;
 //ReaderQuery.java
import java.awt.*;
import java.awt.event.*;
import java.sql.SQLException;
import java.sql.ResultSet;
import javax.swing.*;
public class ReaderQuery extends JFrame{
	Toolkit toolkit=getToolkit();
	String url="src/img/readerquery.jpg";
	Image image=toolkit.getImage(url);
	

	public void paint(Graphics g) {
		// TODO �Զ����ɵķ������
		super.paint(g);
		g.drawImage(image,0,0,this);
	
	}
	Label namelb=new Label("��������"),typelb=new Label("��������");
	TextField nametxt=new TextField(),typetxt=new TextField();
	Button querybtn=new Button("��ѯ");
	Button closebtn=new Button("�˳�");
	Button allinfo=new Button("��ʾȫ��");
	JTable table;
	JTable table1;
	JScrollPane scrollpane;
	JScrollPane scrollpane1;
	String[] heads={"���߱��","��������","��������","�����Ա�","�ɽ�����","�ɽ�����"};
	Object[][] readertable=new Object[30][heads.length];
	Object[][] readertable1=new Object[30][heads.length];
	public ReaderQuery(){
		setTitle("ReaderQuery");
		setSize(800,600);
		setLayout(null);
		setResizable(false);
		
		namelb.setBounds(230,20,50,20);
		typelb.setBounds(410,20,50,20);
		
		nametxt.setBounds(290,20,100,20);
		typetxt.setBounds(470,20,100,20);
		
		querybtn.setBounds(300,60,50,20);
		allinfo.setBounds(365,60,60,20);
		closebtn.setBounds(440,60,50,20);
		add(namelb);add(nametxt);add(typelb);add(typetxt);add(querybtn);add(closebtn);add(allinfo);
		addWindowListener(new WindowAdapter(){
			public void windowClosing(WindowEvent e){
				dispose();
				ShowMain aMain=new ShowMain();
				aMain.setRights(GlobalVar.manage);
			}
		});
		querybtn.addActionListener(new ActionListener(){
			public void actionPerformed(ActionEvent e){
				 queryActionPerformed(e);
			}
		});
		closebtn.addActionListener(new ActionListener(){
			public void actionPerformed(ActionEvent e){
				dispose();
				ShowMain aMain=new ShowMain();
				aMain.setRights(GlobalVar.manage);
			}
		});
		allinfo.addActionListener(new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent e) {
				String sql="select * from reader";
				ResultSet rs=DbOp.executeQuery(sql);
				String[] alloptions={"id","readername","readertype","sex","max_num","days_num"};
				int i=0;
				try {
					while(rs.next()){
						for(int j=0;j<alloptions.length;j++){
							readertable1[i][j]=rs.getString(alloptions[j]);
						}
						i++;
					}
					} catch (SQLException e1) {
						JOptionPane.showMessageDialog(null, e1.getMessage());
					}
					table1=new JTable(readertable1,heads);
					scrollpane1=new JScrollPane(table1);				
					scrollpane1.setBounds(100,100,600,200);
					add(scrollpane1)	;
			}
				
		});

		setLocationRelativeTo(null);
		setVisible(true);
	}
	private void queryActionPerformed(ActionEvent e){
		readertable=new Object[30][heads.length];
		String readername=nametxt.getText(),readertype=typetxt.getText();
		String sql,sql1,sql2,sql3;
		if(readername.equals("")){
			sql1="";
		}else{
			sql1="readername like'"+readername+"%'";
		}
		if(readertype.equals("")){
			sql2="";
		}else{
			sql2="readertype like '"+readertype+"%'";
		}
		if(!readername.equals("")&&!readertype.equals("")){
			sql2="and "+sql2;
		}
		sql="select * from reader where ";
		sql3=sql1+sql2;
		if(!sql3.equals("")){
			sql=sql+sql3;
		}else{
			JOptionPane.showMessageDialog(null,"��������Ҫ��ѯ����Ϣ");
			return;
		}
		try{
			ResultSet rs=DbOp.executeQuery(sql);
			String[] alloptions={"id","readername","readertype","sex","max_num","days_num"};
			int i=0;
			boolean rsnext=false;
			while(rs.next()){
				for(int j=0;j<alloptions.length;j++){
					readertable[i][j]=rs.getString(alloptions[j]);
				}
				i++;
				rsnext=true;
			}
			if(rsnext){
				table=new JTable(readertable,heads);
				scrollpane=new JScrollPane(table);
				scrollpane.setBounds(100,100,600,200);
				add(scrollpane);

				
			}else{
				JOptionPane.showMessageDialog(null,"û�в�ѯ���κ����������Ϣ");
			}
		}catch(SQLException se){
			JOptionPane.showMessageDialog(null,"�Ҳ�����Ҫ��ѯ����Ϣ");

		}
		
	}
	public static void main(String[] args){
		new ReaderQuery();
	}
}