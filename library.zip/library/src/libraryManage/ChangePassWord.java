package libraryManage;
//ChangePassWord.java;
import java.awt.*;
import java.awt.event.*;
import java.sql.ResultSet;
import java.sql.SQLException;
import javax.swing.JOptionPane;
import javax.swing.text.StyledEditorKit.ForegroundAction;
public class ChangePassWord extends Frame{
	
	Toolkit tool= getToolkit();
	String url="src/img/changepass.jpg";
	Image img=tool.getImage(url);
	public static boolean flag=false;//�޸�����ı�־
	public void paint(Graphics g){
		
		g.drawImage(img,200,100,this);
		super.paint(g);
	}
	String[] sign={"�����룺","�趨�����룺","�ظ������룺"};
	Label[] textlb=new Label[3];
	
	TextField[] passtxt=new TextField[3];
	Button reset=new Button("�������趨");
	public ChangePassWord(){
		setTitle("�޸�����");
		setSize(500,400);
		setLayout(null);
		setResizable(false);
		int y=100;
		for(int i=0;i<3;i++){
			textlb[i]=new Label(sign[i]);
			textlb[i].setFont(new Font("����",Font.BOLD,14));
			passtxt[i]=new TextField();
			textlb[i].setBounds(50,y,80,20);
			passtxt[i].setBounds(130,y,100,20);
			passtxt[i].setEchoChar('*');
			add(textlb[i]);add(passtxt[i]);
			y=y+60;
		}
		reset.setBounds(110,280,80,20);
		reset.setFont(new Font("����",Font.BOLD,15));
		add(reset);
		setLocationRelativeTo(null);
		reset.addActionListener(new ActionListener(){
			public void actionPerformed(ActionEvent e){
				setNewPassWord(e);
			}
		});
		addWindowListener(new WindowAdapter(){
			public void windowClosing(WindowEvent e){
				dispose();
				ShowMain bMain=new ShowMain();
				bMain.setRights(GlobalVar.manage);
			}
		});
		setVisible(true);
	}
	public void setNewPassWord(ActionEvent e){
		String[] password=new String[3];
		String sql;
		for (int i=0;i<password.length;i++){
			password[i]=passtxt[i].getText();
		}
		if(!password[0].equals("")){
			sql="select * from user where username='"+GlobalVar.login_user+"'";
		}else{
			JOptionPane.showMessageDialog(null,"Empty String Just Input");
			return;
		}
		
		if(password[0].equals(password[1])){

		}
		try{
			ResultSet rs=DbOp.executeQuery(sql);
			while(rs.next()){
				if(password[0].equals(rs.getString("password"))){
					
				}else{
					JOptionPane.showMessageDialog(null,"Sorroy It's Fail It's not Old PassWord");
					return;

				}
			}
		}catch(SQLException ee){
			JOptionPane.showMessageDialog(null,"Sorroy It's Fail Some Data Wrong");
			return;
			
		}
		if(password[0].equals(password[1])){
			JOptionPane.showMessageDialog(null,"Sorroy It's Fail Same From Old Password");
			return;
		}
		if(!password[1].equals(password[2])){
			JOptionPane.showMessageDialog(null,"Sorroy It's Fail  Again Password wrong");
			return;
		}
		if(password[1].equals("")&&password[1].equals("")){
			JOptionPane.showMessageDialog(null,"Sorroy It's Fail  one Empty");
			return;
			
		}
		sql="";
		sql="update user set password='"+password[1]+"'where username='"+GlobalVar.login_user+"'";
		int da=DbOp.executeUpdate(sql);
		if(da==1){
			dispose();
			new Login();
			JOptionPane.showMessageDialog(null,"yet It's Successed  Update PassWord");
		}else{
			JOptionPane.showMessageDialog(null,"Sorroy It's Fail  try again");
		}
	} 
	public static void main(String[] args){
		new ChangePassWord();
	}
}