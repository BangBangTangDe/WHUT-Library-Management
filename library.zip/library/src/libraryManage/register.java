package libraryManage;
import java.awt.Button;
import java.awt.Choice;
import java.awt.Font;
import java.awt.FontFormatException;
import java.awt.Graphics;
import java.awt.Image;
import java.awt.Label;
import java.awt.TextField;
import java.awt.Toolkit;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.nio.channels.SelectableChannel;
import java.sql.ResultSet;
import java.sql.SQLException;

import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPasswordField;
import javax.swing.JTextField;

public class register extends JFrame{
	String url1="src/img/register_bg.png";
	String url2="src/img/register.gif";
	Toolkit tool=getToolkit();
	Image bg=tool.getImage(url1);
	
	public void paint(Graphics g) {
		super.paint(g);
		g.drawImage(bg, 0,0,this);
	}
	
	private JLabel picture;
	private ImageIcon tupian;
	private Label title;
	private Label username;
	private Label password;
	private Label identity;
	private TextField user;
	private TextField pass;
	private Choice status;
	private Button logon;
	private Button cancel;
	
	public register() {
		
	setTitle("Register");
    setLayout(null);
    setBounds(0,0,730,350);
	tupian=new ImageIcon(url2);
    tupian.setImage(tupian.getImage().getScaledInstance(300, 200, Image.SCALE_DEFAULT));
    picture=new JLabel();
    picture.setIcon(tupian);
    picture.setBounds(10,40,300,200);
    
    title=new Label("User Register");
    title.setBounds(480,50,110,20);
    title.setFont(new Font("����",Font.BOLD,15));
    title.setAlignment(Label.CENTER);
    
    username=new Label("Username:");
    username.setBounds(400,90,90,20);
    username.setFont(new Font("����",Font.BOLD,14));
    username.setAlignment(Label.CENTER);
    password=new Label("Password:");
    password.setBounds(400,130,90,20);
    password.setFont(new Font("����",Font.BOLD,14));
    password.setAlignment(Label.CENTER);
    
    user=new TextField();
    user.setBounds(500,90,120,20);
    pass=new TextField();
    pass.setBounds(500,130,120,20);
    pass.setEchoChar('*');
    
    logon=new Button("Login");
    logon.setFont(new Font("����",Font.BOLD,14));
    logon.setBounds(460,220,60,25);
    
    cancel=new Button("Cancel");
    cancel.setBounds(540,220,60,25);
    cancel.setFont(new Font("����",Font.BOLD,14));
    
    identity=new Label("User status:");
    identity.setAlignment(Label.CENTER);
    identity.setBounds(400,170,90,20);
    identity.setFont(new Font("����",Font.BOLD,14));
    status=new Choice();
    status.add("��ͨ�û�");
    status.add("����Ա");
    status.setBounds(500,170,120,20);
   
    this.add(picture);
    this.add(title);
    this.add(username);
    this.add(password);
    this.add(user);
    this.add(pass);
    this.add(identity);
    this.add(logon);
    this.add(cancel);
    this.add(status);
    
    setLocationRelativeTo(null);
    setResizable(false);
    setVisible(true);
    logon.addActionListener(new ActionListener() {

		public void actionPerformed(ActionEvent e) {
			String u=user.getText();
			String p=pass.getText();
			if(u.equals("") || p.equals(""))
			{
				JOptionPane.showMessageDialog(null, "�뽫�û��������벹������");return ;
			}
			else {
				boolean flag=false;
				String sql="select username from user where username= '"+u+"';";
				ResultSet rs=DbOp.executeQuery(sql);
				try {
					while(rs.next())
					{
						flag=true;
					}
					if(flag)
					{
						JOptionPane.showMessageDialog(null, "�û����Ѿ�����");
						user.setText("");
						pass.setText("");
						user.requestFocus();
						return ;
					}
					else
					{
						String u2=user.getText();
						String p2=pass.getText();
						String manage=status.getSelectedItem().toString();
						if(manage.equals("����Ա"))
						{
							manage="��";
						}
						else
							manage="��";
						
						String sql1="insert into user (username,password,is_admin) values";
						String sql2=" ("+"'"+u2+"'"+","+"'"+p2+"'"+","+"'"+manage+"'"+");";
						System.out.println(sql1+sql2);
						DbOp.executeUpdate(sql1+sql2);
						JOptionPane.showMessageDialog(null, "Register Successfully");
						dispose();
						new Login();
					}
					
				} catch (SQLException e1) {
					JOptionPane.showMessageDialog(null, e1.getMessage());
				}
			}
		}
	});
    cancel.addActionListener(new ActionListener() {
 		public void actionPerformed(ActionEvent arg0) {
 			dispose();
 			new Login();
 		}
 	});
	}
	
	public static void main(String arg[]) {
		new register();
	}
	
}
