-- MySQL dump 10.13  Distrib 8.0.17, for Win64 (x86_64)
--
-- Host: 127.0.0.1    Database: library
-- ------------------------------------------------------
-- Server version	8.0.17

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `book`
--

DROP TABLE IF EXISTS `book`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `book` (
  `id` varchar(10) NOT NULL,
  `bookname` varchar(45) DEFAULT NULL,
  `booktype` varchar(45) DEFAULT NULL,
  `author` varchar(45) DEFAULT NULL,
  `translator` varchar(45) DEFAULT NULL,
  `publisher` varchar(45) DEFAULT NULL,
  `publish_time` varchar(45) DEFAULT NULL,
  `price` varchar(45) DEFAULT NULL,
  `stock` varchar(45) DEFAULT NULL,
  `page` varchar(45) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `book`
--

LOCK TABLES `book` WRITE;
/*!40000 ALTER TABLE `book` DISABLE KEYS */;
INSERT INTO `book` VALUES ('A00001','国际商务英语互动教程-办公室英语','英语','《英语大世界》','无','世图音响电子出版社','2011-09-01','19','10','111'),('A00002','国际商务英语互动教程-商业行政英语','英语','《英语大世界》','无','世图音响电子出版社','2011-09-01','19','10','135'),('A00003','国际商务英语互动教程-商务交际英语','英语','《英语大世界》','无','世图音响电子出版社','2011-09-01','19','11','134'),('A00004','国际商务英语互动教程-商务信函英语','英语','《英语大世界》','无','世图音响电子出版社','2011-09-01','19','11','208'),('A00005','无师自通-商务英语900句','英语','《英语大世界》','无','世图音响电子出版社','2011-09-01','19','11','155'),('A00006','神童心算','数学','周尔康','无','中国铁道出版社','2008-08-01','27','11','213'),('A00007','五笔学打字','计算机','神龙工作室','无','人民邮电出版社','2002-04-01','29','11','274'),('A00008','8000电脑英汉词典','计算机','前程文化','无','成都时代出版社','2003-06-01','9','11','376'),('A00009','上网10分通','Internet','Galen Grimes（美国）','暂无','山东科学技术出版社','2000-03-01','8','11','156'),('A00010','Dreamweaver 网页制作','计算机','黄世吉 梁元超','无','航空工业出版社','2008-09-01','32','11','281'),('A00011','3ds Max 三维设计经典实录228例','计算机','夏三傲','无','航空工业出版社','2009-07-01','69','11','420'),('A00012','3ds Max 标准教程','计算机','杨庆祥 柏松','无','电子科技大学出版社','2009-06-01','40','11','338'),('A00013','3ds Max Vray 家装效果图精粹','计算机','纪元创意','无','清华大学出版社','2010-04-03','90','11','423'),('A00014','Flash 从新手到高手完全技能进阶','计算机','崔周浩','无','航空工业出版社','2009-09-02','40','11','322'),('A00015','Flash 动画图形创意制作400例','计算机','怡丹科技工作室','无','清华同方光盘电子出版社','2008-04-03','68','11','532'),('A00016','PhotoShop实例创意制作','计算机','怡丹科技工作室','无','清华同方光盘电子出版社','2008-04-03','68','11','548'),('A00017','十万个为什么','文学','佚名','无','北京大学出版社','2009-07-01','32','11','500'),('A00018','IAVA程序设计-实例与操作','程序设计','丁永卫','无','航空工业出版社','2011-06-01','48','11','375'),('A00019','Problem Solving  With C++ Seventh Edition','程序设计','Walter Savitch','周靖','清华大学出版社','2010-01-01','79','11','715'),('A00020','新华字典','其他','中国教育部','无','中国教育出版社','2004-09-01','6','11','875'),('A00021','英汉词典','百科','中国教育部','无','中国教育出版社','2009-04-01','10','11','545'),('A00022','C++面向对象编程','程序设计','佚名','原著','航空工业出版社','2010-09-01','45','11','345');
/*!40000 ALTER TABLE `book` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `borrow`
--

DROP TABLE IF EXISTS `borrow`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `borrow` (
  `id` varchar(10) NOT NULL,
  `book_id` varchar(45) NOT NULL,
  `reader_id` varchar(45) DEFAULT NULL,
  `borrow_date` varchar(45) DEFAULT NULL,
  `back_date` varchar(45) DEFAULT NULL,
  `if_back` varchar(45) DEFAULT NULL,
  PRIMARY KEY (`id`,`book_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `borrow`
--

LOCK TABLES `borrow` WRITE;
/*!40000 ALTER TABLE `borrow` DISABLE KEYS */;
INSERT INTO `borrow` VALUES ('14','A00001','1','2010-07-12','2010-07-12','是'),('15','A00001','1','2010-07-12','','否'),('16','A00004','2','2013-01-12','2010-07-12','是'),('17','A00005','2','2008-01-12','2013-09-03','是'),('19','A00004','2','2010-07-12','2013-09-03','是'),('20','A00009','7','2013-09-01','','否'),('21','A00001','7','2013-08-01','','否'),('22','A00002','7','2013-09-01','','否'),('23','A00004','7','2013-08-11','','否'),('24','A00005','5','2013-09-01','2013-09-03','是'),('25','A00005','8','2013-09-03','','否');
/*!40000 ALTER TABLE `borrow` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `reader`
--

DROP TABLE IF EXISTS `reader`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `reader` (
  `id` varchar(10) NOT NULL,
  `readername` varchar(45) DEFAULT NULL,
  `readertype` varchar(45) DEFAULT NULL,
  `sex` varchar(45) DEFAULT NULL,
  `max_num` varchar(45) DEFAULT NULL,
  `days_num` varchar(45) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `reader`
--

LOCK TABLES `reader` WRITE;
/*!40000 ALTER TABLE `reader` DISABLE KEYS */;
INSERT INTO `reader` VALUES ('1','王丽丽','教师','女','10','90'),('10','黄汉明','教师','男','5','90'),('2','张三','教师','男','10','90'),('5','吴雨','学生','男','3','60'),('6','张欣欣','学生','女','3','60'),('7','杨秀杰','学生','女','3','60'),('8','刘浩','学生','男','3','60'),('9','李阳','教师','男','5','90');
/*!40000 ALTER TABLE `reader` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `user`
--

DROP TABLE IF EXISTS `user`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `user` (
  `id` int(11) NOT NULL,
  `username` varchar(45) DEFAULT NULL,
  `password` varchar(45) DEFAULT NULL,
  `is_admin` varchar(45) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `user`
--

LOCK TABLES `user` WRITE;
/*!40000 ALTER TABLE `user` DISABLE KEYS */;
INSERT INTO `user` VALUES (1,'admin','1234','是');
/*!40000 ALTER TABLE `user` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Dumping events for database 'library'
--

--
-- Dumping routines for database 'library'
--
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2019-12-15 22:04:25
